from Website import create_app  # taking from folder and importing function

app = create_app()  # referring to function to make it easier

if __name__ == '__main__':  # says only if we run this file we'll execute the app.run
    # run flask app // Debug=True it will run regardless of change
    app.run(debug=True)
