from flask import Flask
from flask_sqlalchemy import SQLAlchemy  # importing database
from os import path
from flask_login import LoginManager

db = SQLAlchemy()  # defining database / intitialized
DB_NAME = "database.db"


def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'OHALA'
    # tells the program its gonna use the database // telling flask its located in the website folder
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_NAME}'
    db.init_app(app)

    from .views import views
    from .auth import auth

    # you can change the prefix but then would have to chnage it in the other files
    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')

    # referencing class because you cant reference variable with a dot
    from .models import User, Note

    create_database(app)

    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(id):
        # looking for primary key // Usually necessary for flask login
        return User.query.get(int(id))

    return app


def create_database(app):  # created a fucntion to check if the database exsists
    if not path.exists('Website/' + DB_NAME):
        # telling flask Alc which app the database is for
        db.create_all(app=app)
        print('Created Database')
