# Blueprint means having a bunch of Urls in side // render is taking HMTL I made
from flask import Blueprint, render_template, flash, request
from flask_login import login_user, logout_user, current_user, login_required
from . import db
# check all decorators (@)
# the __name at the end is how you define Blueprint
views = Blueprint('views', __name__)


@views.route('/', methods=['GET', 'POST'])
@login_required  # ensures you cant to homepage unless logged in
# type in / > will go to main page of website
def home():  # whatever in the home is what views is going to run
    if request.method == 'POST':
        Note = request.form.get('Note')

        if len(Note) < 1:
            flash('Note is too short!', category='error')
        else:
            new_note = Note(data=Note, user_id=current_user.id)
            db.session.add(new_note)
            db.session.commit()
            flash('Note added!', category='Success')

    return render_template('home.html', user=current_user)  # 1st root
