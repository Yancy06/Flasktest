from . import db  # importing db object from website
from flask_login import UserMixin  # helps with login
from sqlalchemy.sql import func


class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10000))
    # func.now automatically gets time
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    # this key will establihs the relationship of class user & note
    # user = class / .id = id under class
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

# class Reminder can be used to set reminders or store // library has more


class User(db.Model, UserMixin):  # these are the user models
    id = db.Column(db.Integer, primary_key=True)  # unique identifier
    # any string must have length
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    notes = db.relationship('Note')  # calling Note so it can merge
